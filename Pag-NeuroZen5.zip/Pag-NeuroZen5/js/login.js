import { supabase } from './supabaseConfig.js';

const container = document.querySelector(".container");
const btnSignIn = document.getElementById("btn-sign-in");
const btnSignUp = document.getElementById("btn-sign-up");

btnSignIn.addEventListener("click", ()=>{
container.classList.remove("toggle");
});
btnSignUp.addEventListener("click", ()=>{
    container.classList.add("toggle");
});
// Manejar formulario de Registrarse
    const signUpForm = document.querySelector('.sign-up');
    signUpForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const fullName = document.getElementById('signup-fullname').value.trim();
        const email = document.getElementById('signup-email').value.trim();
        const password = document.getElementById('signup-password').value.trim();
        
        console.log('Email enviado:', email);

        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Por favor, ingrese un correo electrónico válido.');
            return;
        }

        try {
            const { data: { user }, error } = await supabase.auth.signUp({ email, password });
            if (error) {
                if (error.message.includes('duplicate key value') || error.message.includes('already registered')) {
                    alert('Este email ya está registrado. Intenta iniciar sesión.');
                } else {
                    alert('Error en el registro: ' + error.message);
                }
                return;
            }
            
            console.log('Insertando en profiles:', { user_id: user.id, full_name: fullName });
            const { error: profileError } = await supabase
                .from('profiles')
                .insert([{ user_id: user.id, full_name: fullName }]);
            
            if (profileError) {
                alert('Error al guardar perfil: ' + profileError.message);
                return;
            }
            
            alert('¡Registro exitoso! Iniciando sesión automáticamente...');
            window.location.href = 'index.html';
        } catch (err) {
            alert('Error inesperado: ' + err.message);
        }
    });

    // Manejar formulario de Iniciar Sesión
    const signInForm = document.querySelector('.sign-in');
    signInForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('signin-email').value.trim();
        const password = document.getElementById('signin-password').value.trim();
        
        console.log('Email de login:', email);

        try {
            const { data: { user }, error } = await supabase.auth.signInWithPassword({ email, password });
            if (error) {
                alert('Error en el inicio de sesión: ' + error.message);
                return;
            }
            
            // Verificar que la sesión se creó correctamente antes de redirigir
            const { data: { session } } = await supabase.auth.getSession();
            if (session) {
                alert('¡Inicio de sesión exitoso!');
                window.location.href = 'index.html';
            } else {
                alert('Error: No se pudo establecer la sesión.');
            }
        } catch (err) {
            alert('Error inesperado: ' + err.message);
        }
    });
