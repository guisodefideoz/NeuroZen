import { createClient } from 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js/+esm'
    const supabaseUrl = 'https://oeumyogmiggkvniapchm.supabase.co'
    const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im9ldW15b2dtaWdna3ZuaWFwY2htIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTUwNzU3NjYsImV4cCI6MjA3MDY1MTc2Nn0.mEJ08EGh0BTv8Ry3YrIjwbLPAVKo3xG53SkE5aceSQI'
export const supabase = createClient(supabaseUrl, supabaseKey)
