// js/animations.js
// js/animations.js
document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('.fade-in-section');

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                // NO desobservamos: así se repite al subir/bajar
            } else {
                // Al salir del viewport, quitamos la clase para que se repita
                entry.target.classList.remove('visible');
            }
        });
    }, {
        threshold: 0.15,           // Más suave: activa antes
        rootMargin: '0px 0px -100px 0px'  // Empieza la animación un poco antes
    });

    sections.forEach(section => {
        observer.observe(section);
    });

    // Forzar body loaded
    document.body.classList.add('loaded');
});



/* document.addEventListener('DOMContentLoaded', () => {
            const sections = document.querySelectorAll('.fade-in-section');

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                    }
                });
            }, {
                threshold: 0.1,
                rootMargin: "0px 0px -50px 0px"
            });

            sections.forEach(section => {
                observer.observe(section);
            });

            document.body.classList.add('loaded');
        });*/

/*document.addEventListener('DOMContentLoaded', () => {
    const sections = document.querySelectorAll('.fade-in-section');

    const observer = new IntersectionObserver((entries, observer) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
                observer.unobserve(entry.target); // Deja de observar tras activarse
            }
        });
    }, {
        threshold: 0.1, // Activa cuando el 10% es visible
        rootMargin: "0px 0px -50px 0px" // Inicia un poco antes
    });

    sections.forEach(section => {
        observer.observe(section);
    });

    // Asegura que el body esté cargado
    document.body.classList.add('loaded');
});*/