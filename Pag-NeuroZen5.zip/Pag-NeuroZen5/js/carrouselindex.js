 // JavaScript del Carrusel
        let currentIndex = 0;
        const slides = document.querySelectorAll('.carousel-slide');
        const indicators = document.querySelectorAll('.indicator');
        const totalSlides = slides.length;

        function showSlide(index) {
            if (index >= totalSlides) {
                currentIndex = 0;
            } else if (index < 0) {
                currentIndex = totalSlides - 1;
            } else {
                currentIndex = index;
            }

            const offset = -currentIndex * 100;
            document.querySelector('.carousel-slides').style.transform = `translateX(${offset}%)`;

            // Actualizar indicadores
            indicators.forEach((indicator, i) => {
                indicator.classList.toggle('active', i === currentIndex);
            });
        }

        function moveSlide(direction) {
            showSlide(currentIndex + direction);
        }

        function currentSlide(index) {
            showSlide(index);
        }

        // Esperar a que el DOM esté completamente cargado
        document.addEventListener('DOMContentLoaded', function() {
            // Agregar event listeners a los indicadores
            const indicators = document.querySelectorAll('.indicator');
            indicators.forEach((indicator, index) => {
                indicator.addEventListener('click', function() {
                    currentSlide(index);
                });
            });
        });

        // Auto-play del carrusel
        setInterval(() => {
            moveSlide(1);
        }, 5000); // Cambia cada 5 segundos