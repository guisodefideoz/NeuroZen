// js/index.js
import { supabase } from './supabaseConfig.js';

document.addEventListener('DOMContentLoaded', async () => {
    const { data: { session } } = await supabase.auth.getSession();

    if (!session) {
        // Si no hay sesión, redirigir a login.html
        alert('Sesión no encontrada. Por favor, inicia sesión.');
        window.location.href = 'login.html';
    } else {
        // Si hay sesión, puedes mostrar información del usuario
        const user = session.user;
        const { data: profile } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('user_id', user.id)
            .single();

        if (profile) {
            document.getElementById('user-name')?.textContent = profile.full_name; // Ajusta el ID según tu HTML
        } else {
            console.log('Perfil no encontrado para el usuario:', user.id);
        }
    }
});