import { supabase } from './supabaseConfig.js';

 document.getElementById('doctorForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const successMessage = document.getElementById('successMessage');
            successMessage.classList.add('show');
            
            // Simular envío (aquí integrarías con Supabase)
            console.log('Formulario enviado:', {
                nombre: document.getElementById('nombre').value,
                apellido: document.getElementById('apellido').value,
                email: document.getElementById('email').value,
                telefono: document.getElementById('telefono').value,
                especialidad: document.getElementById('especialidad').value,
                matricula: document.getElementById('matricula').value,
                experiencia: document.getElementById('experiencia').value,
                motivacion: document.getElementById('motivacion').value
            });
            
            setTimeout(() => {
                successMessage.classList.remove('show');
                this.reset();
            }, 3000);
        });