import { supabase } from './supabaseConfig.js';



async function loadHeader() {
    try {
        console.log('Intentando cargar header.html...');
        const response = await fetch('header.html');
        if (!response.ok) {
            throw new Error(`No se pudo cargar header.html. Estado: ${response.status}`);
        }
        const headerHTML = await response.text();
        document.getElementById('dynamic-header').innerHTML = headerHTML;
        console.log('Header cargado correctamente.');
        
        // Verificar sesión y actualizar el header
        await updateUserInfo();
    } catch (error) {
        console.error('Error cargando header:', error.message);
    }
}

async function updateUserInfo() {
    const { data: { session } } = await supabase.auth.getSession();
    const userIconLi = document.querySelector('.image-replacement');

    if (!userIconLi) {
        console.error('No se encontró el elemento .image-replacement');
        return;
    }

    if (!session) {
        console.log('No hay sesión activa, manteniendo el ícono.');
        return;
    } else {
        console.log('Sesión encontrada, obteniendo perfil...');
        const user = session.user;
        const { data: profile, error } = await supabase
            .from('profiles')
            .select('full_name')
            .eq('user_id', user.id)
            .single();

        if (error) {
            console.error('Error al obtener el perfil:', error.message);
            userIconLi.innerHTML = '<a href="login.html"><img src="imgs/usuario-circulo.png" alt="Imagen de cuenta" height="50px" width="50px"></a>';
        } else if (profile && profile.full_name) {
            console.log('Perfil encontrado, actualizando con:', profile.full_name);
            userIconLi.innerHTML = `<a href="#" id="user-name" style="display: flex; align-items: center; padding: 15px 20px; font-size: 25px; color: #4f8479; font-weight: 600;">${profile.full_name}</a>`;
        } else {
            userIconLi.innerHTML = '<a href="login.html"><img src="imgs/usuario-circulo.png" alt="Imagen de cuenta" height="50px" width="50px"></a>';
        }
    }
}

document.addEventListener('DOMContentLoaded', loadHeader);

// Opcional: Cerrar sesión al hacer clic en el nombre
document.addEventListener('click', async (e) => {
    const userName = document.getElementById('user-name');
    if (userName && e.target === userName) {
        const { error } = await supabase.auth.signOut();
        if (error) {
            alert('Error al cerrar sesión: ' + error.message);
        } else {
            alert('Sesión cerrada. Redirigiendo a login...');
            window.location.href = 'login.html';
        }
    }
});