// js/transition.js
document.addEventListener('DOMContentLoaded', () => {
    const videoContainer = document.querySelector('.video-container');
    const content = document.querySelector('.content');
    const footer = document.querySelector('footer');

    setTimeout(() => {
        videoContainer.classList.add('fade-out');
        setTimeout(() => {
            content.classList.add('show');
            footer.classList.add('show'); // Muestra el footer
        }, 1000); // Espera 1 segundo para que el fade-out termine
    }, 0); // 7 segundos de duración del video
});