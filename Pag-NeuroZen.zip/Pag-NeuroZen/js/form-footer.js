import { supabase } from './supabaseConfig.js';


document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('questionForm');
    const successMessage = document.getElementById('successMessage');

    if (!form) {
        console.error('Formulario no encontrado en el DOM');
        return;
    }
    if (!successMessage) {
        console.error('Elemento successMessage no encontrado en el DOM');
        return;
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        console.log('Formulario enviado - Iniciando inserción...');

        const name = form.name.value.trim();
        const email = form.email.value.trim();
        const category = form.category.value.trim();
        const question = form.question.value.trim();

        console.log('Datos capturados:', { nombre: name, email, categoria: category, pregunta: question });

        if (category === 'Selecciona una categoría') {
            alert('Selecciona una categoría válida');
            return;
        }

        try {
            const { data, error } = await supabase
                .from('preguntas')
                .insert([{ nombre: name, email: email, categoria: category, pregunta: question }]);

            if (error) throw error;
            console.log('Inserción exitosa - Mostrando mensaje:', data);
            successMessage.textContent = '¡Gracias por tu pregunta! Te responderemos pronto.';
            successMessage.classList.add('show');
            setTimeout(() => {
                successMessage.classList.remove('show');
                form.reset(); // Limpia el formulario cuando el mensaje desaparece
            }, 2000);
        } catch (error) {
            console.error('Error detallado:', error.message);
            alert('Hubo un error al enviar tu pregunta: ' + error.message);
        }
    });
});
